# COMPLEXE SCOLAIRE SAINT VICTOR — Application Web
Version web responsive/mobile-first.
## Lancement
Ouvrir `saint-victor-web.html` dans Safari/Chrome.
Pour une URL publique, publier ce dossier sur un hébergeur statique (Vercel, Netlify, GitHub Pages, etc.).
Les données de cette version sont conservées dans le navigateur via localStorage.
## Modules
Tableau de bord, élèves, parents, études, présences, notes, finances, personnel, rapports, utilisateurs, paramètres, export JSON.
## Important
Cette version est un prototype fonctionnel autonome. Pour la production multi-utilisateurs, connecter Supabase (Auth + PostgreSQL + Storage + RLS) et déployer via Vercel.
